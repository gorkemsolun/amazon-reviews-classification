# Amazon-Reviews-Classification

Görkem Kadir Solun

NOTE: The program creates a chart. By closing the chart, you can run the models.

NOTE: Setup your project file structure as follows:
AMAZON-REVIEWS-CLASSIFICATION
│
├── dataset
│   ├── x_test.csv
│   ├── x_train.csv
│   ├── y_test.csv
│   └── y_train.csv
│
├── q2main.py
├── README.txt
└── report.pdf


To run: python q2main.py

